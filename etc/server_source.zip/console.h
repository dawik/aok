/*
File: net.c
By: David Wikmans
Created 13 april, 2011.
*/

int consoleThread(void *data); //David
