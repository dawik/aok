/*
 * File:   sound.h
 * Author: Projektgrupp 4
 * Created by: Emil Lundmark
 * Revisioned by:
 *
 * Created on May 2, 2011
 */

 //Sounds

Mix_Chunk *attack_sound;
Mix_Chunk *attack_sound2;
Mix_Chunk *attack_sound3;
Mix_Chunk *follow_sound;
Mix_Chunk *underattack_sound;
Mix_Chunk *work_sound;
Mix_Chunk *win_sound;
Mix_Chunk *lose_sound;
Mix_Chunk *unitlost_sound;
Mix_Music *music_sound;
Mix_Chunk *move_sound1;
Mix_Chunk *move_sound2;
Mix_Chunk *move_sound3;
Mix_Chunk *cantwalk_sound;
Mix_Chunk *menu_sound;
Mix_Chunk *unitmax_sound;
