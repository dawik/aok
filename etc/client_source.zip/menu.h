/*
 * File:   menu.h
 * Author: Projektgrupp 4
 * Created by: Adam Frankenberg
 * Revisioned by:
 *
 * Created on April 2, 2011
 */

void menuEvent(SDL_Event* event); //Adam

void startMenuEvent(SDL_Event* event); //Adam

int test;
int helpmenu;
int optionsmenu;
int menu;
int enter;
int arrow;
int options;
int start;
int resolution;
int begin;
int quit;
int soundset;
int volume1;
int inter;
int textur;
int x;
int y;
int fullscreen;
int grafik;
int credits;
