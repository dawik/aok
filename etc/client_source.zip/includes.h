#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

#include <SDL/SDL.h>
#include <GL/freeglut.h>
#include <GL/glu.h>
#include <SDL/SDL_thread.h>
#include <SDL/SDL_net.h>
#include <SDL/SDL_events.h>
#include <SDL/SDL_opengl.h>
#include <SDL/SDL_mutex.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
